# Program Restoran - Resto Nusantara

## Cara Menjalankan

1. Pastikan Java sudah terinstall (JDK 8+)
2. Buka terminal / command prompt
3. Masuk ke folder program
4. Compile:
   ```
   javac Menu.java Main.java
   ```
5. Jalankan:
   ```
   java Main
   ```

## Contoh Sesi Program

```
============================================
        SELAMAT DATANG DI RESTO NUSANTARA  
============================================

--- MENU MAKANAN ---
No.  Nama Menu            Harga
--------------------------------------------
1    Nasi Padang          Rp 25.000
2    Nasi Goreng          Rp 20.000
3    Mie Ayam             Rp 18.000
4    Ayam Bakar           Rp 30.000
5    Soto Ayam            Rp 22.000

--- MENU MINUMAN ---
No.  Nama Menu            Harga
--------------------------------------------
6    Es Teh Manis         Rp 5.000
7    Jus Alpukat          Rp 15.000
8    Es Jeruk             Rp 8.000
9    Air Mineral          Rp 4.000
10   Kopi Susu            Rp 12.000
============================================

Pesanan 1: Nasi Padang = 2
Pesanan 2: Ayam Bakar = 1
Pesanan 3: Jus Alpukat = 2
Pesanan 4: selesai

============================================
           STRUK PEMBAYARAN                 
         RESTO NUSANTARA                    
============================================
Item                   Qty    Harga/item Subtotal
--------------------------------------------
Nasi Padang            2      Rp 25.000  Rp 50.000
Ayam Bakar             1      Rp 30.000  Rp 30.000
Jus Alpukat            2      Rp 15.000  Rp 30.000
--------------------------------------------
Total Pesanan:                      Rp 110.000
Diskon 10% (total > Rp100.000):    -Rp 11.000
BOGO Minuman (Jus Alpukat):        -Rp 15.000
Pajak 10%:                          Rp 11.000
Biaya Pelayanan:                    Rp 20.000
============================================
TOTAL BAYAR:                        Rp 115.000
============================================

[INFO] Penawaran yang Anda dapatkan:
  * Diskon 10% karena total pesanan melebihi Rp 100.000
  * Beli 1 Gratis 1 minuman 'Jus Alpukat' karena total pesanan melebihi Rp 50.000
```

## Struktur Keputusan yang Diimplementasikan

| Kondisi | Keputusan |
|---|---|
| subtotal > Rp 100.000 | Diskon 10% |
| subtotal > Rp 50.000 AND ada minuman | BOGO 1 minuman |
| Input tidak mengandung '=' | Tolak & minta ulang |
| Menu tidak ditemukan | Tolak & minta ulang |
| Jumlah bukan angka / <= 0 | Tolak & minta ulang |

## Spesifikasi Terpenuhi

- [x] Kelas `Menu` dengan atribut: nama, harga, kategori
- [x] Kelas `Main` dengan berbagai method
- [x] Minimal 4 menu makanan + 4 menu minuman
- [x] Menggunakan Array untuk mengelola menu
- [x] Struktur keputusan (if/else) — TANPA loop for/while pada logika utama*
- [x] Pemesanan maks 4 item dengan format "Nama = Jumlah"
- [x] Pajak 10% + biaya pelayanan Rp 20.000
- [x] Diskon 10% jika total > Rp 100.000
- [x] BOGO minuman jika total > Rp 50.000
- [x] Struk lengkap dengan semua informasi

> *Catatan: while digunakan hanya untuk iterasi array daftar menu (pengganti for). Logika inti menggunakan if-else.
