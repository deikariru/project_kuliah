import java.util.Scanner;

public class Main {

    // ========================
    // DATA MENU RESTORAN
    // ========================
    static Menu[] daftarMenu = {
        // Makanan (minimal 4)
        new Menu("Nasi Padang",      25000, "makanan"),
        new Menu("Nasi Goreng",      20000, "makanan"),
        new Menu("Mie Ayam",         18000, "makanan"),
        new Menu("Ayam Bakar",       30000, "makanan"),
        new Menu("Soto Ayam",        22000, "makanan"),
        // Minuman (minimal 4)
        new Menu("Es Teh Manis",      5000, "minuman"),
        new Menu("Jus Alpukat",      15000, "minuman"),
        new Menu("Es Jeruk",          8000, "minuman"),
        new Menu("Air Mineral",       4000, "minuman"),
        new Menu("Kopi Susu",        12000, "minuman")
    };

    // Array pesanan (maksimal 4 item)
    static String[] namaPesanan   = new String[4];
    static int[]    jumlahPesanan = new int[4];
    static int      totalItemDipesan = 0;

    // ========================
    // MAIN METHOD
    // ========================
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        tampilkanMenu();
        terimaPesanan(sc);
        cetakStruk();

        sc.close();
    }

    // ========================
    // 1. TAMPILKAN MENU
    // ========================
    static void tampilkanMenu() {
        System.out.println("============================================");
        System.out.println("        SELAMAT DATANG DI RESTO NUSANTARA  ");
        System.out.println("============================================");

        System.out.println("\n--- MENU MAKANAN ---");
        System.out.printf("%-5s %-20s %s%n", "No.", "Nama Menu", "Harga");
        System.out.println("--------------------------------------------");

        int no = 1;
        // Tampilkan makanan
        if (daftarMenu[0].getKategori().equals("makanan")) {
            // indeks 0-4 adalah makanan
            tampilkanKategori("makanan", no);
        }

        System.out.println("\n--- MENU MINUMAN ---");
        System.out.printf("%-5s %-20s %s%n", "No.", "Nama Menu", "Harga");
        System.out.println("--------------------------------------------");
        tampilkanKategori("minuman", 6);

        System.out.println("============================================");
    }

    static void tampilkanKategori(String kategori, int startNo) {
        int no = startNo;
        int i = 0;
        while (i < daftarMenu.length) {
            if (daftarMenu[i].getKategori().equals(kategori)) {
                System.out.printf("%-5d %-20s Rp %,.0f%n",
                    no, daftarMenu[i].getNama(), daftarMenu[i].getHarga());
                no++;
            }
            i++;
        }
    }

    // ========================
    // 2. TERIMA PESANAN
    // ========================
    static void terimaPesanan(Scanner sc) {
        System.out.println("\nSilakan masukkan pesanan Anda (maksimal 4 menu).");
        System.out.println("Format: Nama Menu = Jumlah   (contoh: Nasi Padang = 2)");
        System.out.println("Ketik 'selesai' jika sudah selesai memesan.\n");

        int slot = 0;
        while (slot < 4) {
            System.out.print("Pesanan " + (slot + 1) + ": ");
            String input = sc.nextLine().trim();

            if (input.equalsIgnoreCase("selesai")) {
                break;
            }

            // Parsing input "Nama Menu = Jumlah"
            if (!input.contains("=")) {
                System.out.println("  [!] Format salah. Gunakan: Nama Menu = Jumlah");
                continue;
            }

            String[] bagian = input.split("=");
            if (bagian.length != 2) {
                System.out.println("  [!] Format salah. Gunakan: Nama Menu = Jumlah");
                continue;
            }

            String namaInput = bagian[0].trim();
            String jumlahStr = bagian[1].trim();

            // Validasi jumlah adalah angka positif
            int jumlah;
            try {
                jumlah = Integer.parseInt(jumlahStr);
                if (jumlah <= 0) {
                    System.out.println("  [!] Jumlah harus lebih dari 0.");
                    continue;
                }
            } catch (NumberFormatException e) {
                System.out.println("  [!] Jumlah harus berupa angka.");
                continue;
            }

            // Cek apakah menu ada di daftar
            boolean ditemukan = cariMenu(namaInput) != null;
            if (!ditemukan) {
                System.out.println("  [!] Menu '" + namaInput + "' tidak ditemukan. Periksa kembali nama menu.");
                continue;
            }

            namaPesanan[slot]   = namaInput;
            jumlahPesanan[slot] = jumlah;
            slot++;
        }

        totalItemDipesan = slot;

        if (totalItemDipesan == 0) {
            System.out.println("\nTidak ada pesanan yang dimasukkan. Program selesai.");
            System.exit(0);
        }
    }

    // Helper: cari menu berdasarkan nama (case-insensitive)
    static Menu cariMenu(String nama) {
        int i = 0;
        while (i < daftarMenu.length) {
            if (daftarMenu[i].getNama().equalsIgnoreCase(nama)) {
                return daftarMenu[i];
            }
            i++;
        }
        return null;
    }

    // ========================
    // 3. HITUNG TOTAL BIAYA
    // ========================
    static double hitungSubtotal() {
        double subtotal = 0;
        int i = 0;
        while (i < totalItemDipesan) {
            Menu m = cariMenu(namaPesanan[i]);
            if (m != null) {
                subtotal += m.getHarga() * jumlahPesanan[i];
            }
            i++;
        }
        return subtotal;
    }

    // Cek apakah ada item minuman yang dipesan
    static boolean adaMinuman() {
        int i = 0;
        while (i < totalItemDipesan) {
            Menu m = cariMenu(namaPesanan[i]);
            if (m != null && m.getKategori().equals("minuman")) {
                return true;
            }
            i++;
        }
        return false;
    }

    // Ambil nama minuman pertama yang dipesan (untuk penawaran BOGO)
    static String getNamaMinumanPertama() {
        int i = 0;
        while (i < totalItemDipesan) {
            Menu m = cariMenu(namaPesanan[i]);
            if (m != null && m.getKategori().equals("minuman")) {
                return m.getNama();
            }
            i++;
        }
        return "-";
    }

    // Ambil harga minuman pertama (untuk nilai BOGO)
    static double getHargaMinumanPertama() {
        int i = 0;
        while (i < totalItemDipesan) {
            Menu m = cariMenu(namaPesanan[i]);
            if (m != null && m.getKategori().equals("minuman")) {
                return m.getHarga();
            }
            i++;
        }
        return 0;
    }

    // ========================
    // 4. CETAK STRUK PESANAN
    // ========================
    static void cetakStruk() {
        double subtotal        = hitungSubtotal();
        double biayaPajak      = subtotal * 0.10;
        double biayaPelayanan  = 20000;
        double diskon          = 0;
        double nilaiBoGo       = 0;
        boolean adaDiskon      = subtotal > 100000;
        boolean adaBogo        = subtotal > 50000 && adaMinuman();

        // Hitung diskon
        if (adaDiskon) {
            diskon = subtotal * 0.10;
        }

        // Hitung nilai BOGO (gratis 1 minuman kategori pertama)
        if (adaBogo) {
            nilaiBoGo = getHargaMinumanPertama();
        }

        double totalAkhir = subtotal - diskon - nilaiBoGo + biayaPajak + biayaPelayanan;

        // ---- Cetak ----
        System.out.println("\n");
        System.out.println("============================================");
        System.out.println("           STRUK PEMBAYARAN                 ");
        System.out.println("         RESTO NUSANTARA                    ");
        System.out.println("============================================");
        System.out.printf("%-22s %-6s %-10s %s%n", "Item", "Qty", "Harga/item", "Subtotal");
        System.out.println("--------------------------------------------");

        int i = 0;
        while (i < totalItemDipesan) {
            Menu m = cariMenu(namaPesanan[i]);
            if (m != null) {
                double subtotalItem = m.getHarga() * jumlahPesanan[i];
                System.out.printf("%-22s %-6d Rp%,-8.0f Rp%,.0f%n",
                    m.getNama(), jumlahPesanan[i], m.getHarga(), subtotalItem);
            }
            i++;
        }

        System.out.println("--------------------------------------------");
        System.out.printf("%-35s Rp%,.0f%n", "Total Pesanan:", subtotal);

        // Diskon
        if (adaDiskon) {
            System.out.printf("%-35s -Rp%,.0f%n", "Diskon 10% (total > Rp100.000):", diskon);
        }

        // BOGO
        if (adaBogo) {
            System.out.printf("%-35s -Rp%,.0f%n",
                "BOGO Minuman (" + getNamaMinumanPertama() + "):", nilaiBoGo);
        }

        System.out.printf("%-35s Rp%,.0f%n", "Pajak 10%:", biayaPajak);
        System.out.printf("%-35s Rp%,.0f%n", "Biaya Pelayanan:", biayaPelayanan);
        System.out.println("============================================");
        System.out.printf("%-35s Rp%,.0f%n", "TOTAL BAYAR:", totalAkhir);
        System.out.println("============================================");

        // Informasi penawaran yang berlaku
        if (adaDiskon || adaBogo) {
            System.out.println("\n[INFO] Penawaran yang Anda dapatkan:");
            if (adaDiskon) {
                System.out.println("  * Diskon 10% karena total pesanan melebihi Rp 100.000");
            }
            if (adaBogo) {
                System.out.println("  * Beli 1 Gratis 1 minuman '" + getNamaMinumanPertama()
                    + "' karena total pesanan melebihi Rp 50.000");
            }
        }

        System.out.println("\nTerima kasih telah berkunjung ke Resto Nusantara!");
        System.out.println("============================================");
    }
}
